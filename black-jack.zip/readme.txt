﻿=== Blackjack Cursor Set ===

By: Michaelpie (http://www.rw-designer.com/user/60880) Pikachu3@comcast.net

Download: http://www.rw-designer.com/cursor-set/black-jack

Author's description:

Incomplete Card-Game themed cursor set. I will be working on this for a little while.

Hope you enjoy!

==========

License: Released to Public Domain

You are free:

* To use this work for any legal purpose.