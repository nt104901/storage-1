﻿=== Card Symbols Icon Set ===

By: 1marky7

Download: https://www.rw-designer.com/icon-set/card-symbols

Author's description:

These card icons were made together with and Cards.ani cursor in the [[cursor-set/mini-games|mini games cursor set]].

==========

License: Creative Commons - Noncommercial

You are free:

* To Share - To copy, distribute and transmit the work.
* To Remix - To adapt the work.

Under the following conditions:

* Noncommercial - You may not use this work for commercial purposes.