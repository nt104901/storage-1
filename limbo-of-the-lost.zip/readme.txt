﻿=== LIMBO OF THE LOST Cursor Set ===

By: THTH

Download: http://www.rw-designer.com/cursor-set/limbo-of-the-lost

Author's description:

PLEASE READ!!!
THESE CURSORS ARE SET ON A 48pixels CANVAS!
TO SEE THEM PROPERLY, ADJUST
THE "CURSOR SIZE" SLIDER ON 2 OR 5
BEFORE APPLYING A SET MADE WITH THESE!
¡¡¡POR FAVOR LEER!!!
¡Estos cursores están configurados en un lienzo de 48 píxeles!
Para verlos correctamente, ajusta el control de “Tamaño del cursor” a 2 o 5
antes de aplicar un conjunto creado con estos.
Cursores del juego LIMBO OF THE LOST, lanzado en el año 2008.
Juego de aventura gráfica oscura y surrealista: explora mundos extraños, resuelve puzles y descubre una historia psicológica y perturbadora.

==========

License: Released to Public Domain

You are free:

* To use this work for any legal purpose.