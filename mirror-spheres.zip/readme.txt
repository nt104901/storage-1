﻿=== Mirror Spheres Icon Set ===

By: 

Download: https://www.rw-designer.com/icon-set/mirror-spheres

Author's description:

Ten gazing mirror spheres for the relaxing pleasure. Various degrees of shininess with the mirror spheres depending on polish graze. Gold and bronze spheres and a rainbow spheres. All other mirror spheres count as silver spheres.

==========

License: Released to Public Domain

You are free:

* To use this work for any legal purpose.