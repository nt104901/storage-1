﻿=== Number Buttons Icon Set ===

By: 

Download: https://www.rw-designer.com/icon-set/number-buttons

Author's description:

A set of 9 number buttons. Useful in programs that require selecting numbers for a purpose.

==========

License: Released to Public Domain

You are free:

* To use this work for any legal purpose.