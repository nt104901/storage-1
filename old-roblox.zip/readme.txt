﻿=== Old Roblox Cursor Set ===

By: 4W2 (http://www.rw-designer.com/user/74045) mrkrab65@gmail.com

Download: http://www.rw-designer.com/cursor-set/old-roblox

Author's description:

Long time no see, and happy new year!

These are a set of old ROBLOX Cursors. These are the cursors from pre 2015 I think.

In NO WAY am I copying Romanek159's ROBLOX Cursor set. Yes, they are also from ROBLOX, but they are the old ones that I decided to make into a cursor set.

Hope you enjoy!

==========

License: Released to Public Domain

You are free:

* To use this work for any legal purpose.