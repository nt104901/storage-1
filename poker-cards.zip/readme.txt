﻿=== POKER CARDS Icon Set ===

By: 

Download: https://www.rw-designer.com/icon-set/poker-cards

Author's description:

All cards of a poker set except for Jokers.

Symbols included

Here is download link to the original files along with the original pictures:
http://rapidteria.com/3U3x

it uses adfly, btw

==========

License: Released to Public Domain

You are free:

* To use this work for any legal purpose.