﻿=== Windows games Icon Set ===

By: 

Download: https://www.rw-designer.com/icon-set/wingames

Author's description:

Some icons from games folder
The windows xp are just fanmades
You can use these for your games folder

==========

License: Released to Public Domain

You are free:

* To use this work for any legal purpose.